package com.example.rest.service.ray;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestServiceRayApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestServiceRayApplication.class, args);
	}

}
