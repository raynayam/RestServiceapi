package com.example.rest.service.ray;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestServiceRayApplicationTests {

	@Test
	void contextLoads() {
	}

}
